from django.db import models

# Create your models here.
class Canva(models.Model):
    descricao = models.CharField(max_length=140, verbose_name="Descrição")
    data = models.DateField()

    def __str__(self):
        return "{} ({})".format(self.descricao, self.data)
