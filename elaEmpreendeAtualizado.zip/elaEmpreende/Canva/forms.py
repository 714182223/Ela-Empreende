from django import forms
from .models import Canva

class CanvaForm(forms.ModelForm):
    class Meta:
        model = Canva
        fields = ('descricao', 'data')