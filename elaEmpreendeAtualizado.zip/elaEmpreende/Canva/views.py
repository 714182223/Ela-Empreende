from django.views.generic import TemplateView
from django.views.generic.list import ListView
from django.shortcuts import get_object_or_404
from django.urls import reverse_lazy
from .models import Canva
from django.http import JsonResponse
from django.template.loader import render_to_string
from .forms import CanvaForm

# Create your views here.


def save_form(request, form, template_name):
    data = dict()

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            data['form_is_valid'] = True
            canvas = Canva.objects.all()
            data['html_list'] = render_to_string('listas/parcial_list.html', {'object_list': canvas})
        else:
            data['form_is_valid'] = False

    context = {'form': form}
    data['html_form'] = render_to_string(
        template_name,
        context, request = request
    )
    return JsonResponse(data)

def canva_create(request):
    data = {}
    if request.method == 'POST':
        form = CanvaForm(request.POST)
        if form.is_valid():
            form.save()
            data['form_is_valid'] = True
            canvas = Canva.objects.all()
            data['html_list'] = render_to_string('listas/parcial_list.html', {'object_list': canvas})
        else:
            data['form_is_valid'] = False
    else:
        form = CanvaForm()
    context = {'form': form}
    data['html_form'] = render_to_string('listas/parcial_create.html', {'form': form}, request=request)
    return JsonResponse(data)

def canva_update(request, pk):
    canva = get_object_or_404(Canva, pk=pk)
    if request.method == 'POST':
        form = CanvaForm(request.POST, instance=canva)
    else:
        form = CanvaForm(instance=canva)
    return save_form(request, form, 'listas/parcial_update.html')

def canva_delete(request, pk):
    canva = get_object_or_404(Canva, pk = pk)
    data = dict()
    if request.method == 'POST':
        canva.delete()
        data['form_is_valid'] = True
        canvas = Canva.objects.all()
        data['html_list'] = render_to_string('listas/parcial_list.html', {'object_list': canvas})
    else:
        context = {'canva': canva}
        data['html_form'] = render_to_string('listas/parcial_delete.html',
    context, request = request)
    return JsonResponse(data)




class CanvaList(ListView):
    login_url = '/login/'
    model = Canva
    template_name = 'listas/canva.html'
    success_url = reverse_lazy('listar-canva')


