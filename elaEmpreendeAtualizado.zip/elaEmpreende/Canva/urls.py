from django.urls import path
from .views import CanvaList
from .views import canva_create, canva_update, canva_delete

urlpatterns = [
    path('canva', CanvaList.as_view(), name='listar-canva'),
    path('js/criar', canva_create, name='js-criar'),
    path('js/editar/<int:pk>/', canva_update, name='js-editar'),
    path('js/excluir/<int:pk>', canva_delete, name='js-excluir'),
]
