from django.urls import path
from .views import IndexView, ModeloView, InicioView, minha_view

urlpatterns = [
    path('', IndexView.as_view(), name='inicio'),
    path('modelo/', ModeloView.as_view(), name='modelo'),
    path('inicio/', minha_view, name='inicio'),
]
