from django.shortcuts import render
from django.contrib.auth import login, logout
from django.contrib import messages
from django.urls import reverse_lazy
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth.views import PasswordChangeView
from django.views.generic.edit import CreateView
from .forms import UsuarioForms  # Import your form class
from .models import Empresa  # Import your Empresa model
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User, Group


class UsuarioCreate(CreateView):
    template_name = "usuarios/form.html"
    form_class = UsuarioForms
    success_url = reverse_lazy('inicio')

    def form_valid(self, form):
        # Add the user to the "empresas" group
        grupo = get_object_or_404(Group, name="empresa")
        url = super().form_valid(form)
        
        user = form.save()
        user.groups.add(grupo)

        # Log in the user after successful registration
        login(self.request, user)

        return url
    
def minha_view_de_logout(request):
    logout(request)
    return redirect('inicio')

class AlterarSenhaView(PasswordChangeView):
    template_name = 'usuarios/alterar_senha.html'
    success_url = reverse_lazy('inicio')

    def form_valid(self, form):
        messages.success(self.request, 'Senha alterada com sucesso.')
        return super().form_valid(form)