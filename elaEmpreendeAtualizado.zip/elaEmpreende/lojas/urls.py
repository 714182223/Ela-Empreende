from django.urls import path, include
from .views import (
    LojaCreate, LojaUpdate, LojaDelete, LojaList,
    ComentarioCreate, ComentarioUpdate, ComentarioDelete,
    buscar_produto, iniciar_venda, adicionar_produto, finalizar_venda, get_total_venda, listar_vendas, exibir_comentarios, buscar_produtos_por_loja
)

urlpatterns = [
    path('cadastrar/loja/', LojaCreate.as_view(), name='cadastrar-loja'),
    path('editar/loja/<int:pk>/', LojaUpdate.as_view(), name='editar-loja'),
    path('excluir/loja/<int:pk>/', LojaDelete.as_view(), name='excluir-loja'), 
    path('listar/loja/', LojaList.as_view(), name='listar-loja'),

    path('cadastrar/comentario/', ComentarioCreate.as_view(), name='cadastrar-comentario'),
    path('editar/comentario/<int:pk>/', ComentarioUpdate.as_view(), name='editar-comentario'),
    path('excluir/comentario/<int:pk>/', ComentarioDelete.as_view(), name='excluir-comentario'),
    path('comentarios/', exibir_comentarios, name='exibir_comentarios'),

    path('buscar-produto/', buscar_produto, name='buscar_produto'),
    path('iniciar-venda/', iniciar_venda, name='iniciar_venda'),
    path('adicionar-produto/<int:venda_id>/', adicionar_produto, name='adicionar_produto'),
    path('finalizar-venda/<int:venda_id>/', finalizar_venda, name='finalizar_venda'),
    
    path('get-total-venda/<int:venda_id>/', get_total_venda, name='get_total_venda'),
    path('vendas/', listar_vendas, name='listar_vendas'),
    path('buscar-produtos-por-loja/', buscar_produtos_por_loja, name='buscar_produtos_por_loja'),
    path('select2/', include('django_select2.urls')),

]
