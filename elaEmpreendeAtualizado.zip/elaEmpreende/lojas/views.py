from django.views.generic.edit import CreateView
from .models import Loja, Comentario
from django.urls import reverse_lazy
from django.views.generic.list import ListView
from django.contrib.auth.mixins import LoginRequiredMixin
from .forms import LojaForm, ComentarioForm
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.shortcuts import get_object_or_404
from django.views.generic import ListView
from django.shortcuts import render
from django.shortcuts import redirect
from gerenciar.models import Produto
from django.contrib.auth.decorators import login_required
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.http import JsonResponse
from lojas.models import Venda, ItemVenda
from .forms import AdicionarProdutoForm
from django.db.models import Q
from django.db import transaction
from django.contrib import messages
from django.db.models import Count



@login_required
def buscar_produto(request):
    termo_busca = request.GET.get('termo')
    if termo_busca:
        produtos = Produto.objects.filter(
            (Q(nome__icontains=termo_busca) | Q(codigo_barras__icontains=termo_busca)) &
            Q(usuario=request.user)
        )
        return JsonResponse({'produtos': list(produtos.values('id', 'nome', 'preco'))})
    return JsonResponse({'produtos': []})

from django.http import JsonResponse
from .models import Produto

def buscar_produtos_por_loja(request):
    if request.is_ajax() and request.method == 'GET':
        loja_id = request.GET.get('loja_id')
        produtos = Produto.objects.filter(loja_id=loja_id).values('nome')  # ajuste conforme a estrutura do seu modelo Produto
        return JsonResponse({'produtos': list(produtos)})
    else:
        return JsonResponse({'error': 'Requisição inválida'})

@login_required
def iniciar_venda(request):
    if request.method == 'POST':
        # Obtém o ID da loja selecionada pelo usuário
        loja_id = request.POST.get('loja_id')

        # Verifica se o usuário selecionou uma loja
        if loja_id:
            # Cria a venda associada à loja selecionada
            loja = get_object_or_404(Loja, id=loja_id, usuario=request.user)
            venda = Venda.objects.create(usuario=request.user, loja=loja)
            return redirect('adicionar_produto', venda_id=venda.id)
        else:
            messages.error(request, "Por favor, selecione uma loja para iniciar a venda.")
    else:
        # Obtém todas as lojas do usuário para exibir no formulário
        lojas = Loja.objects.filter(usuario=request.user)
        return render(request, 'iniciar_venda.html', {'lojas': lojas})

    return redirect('alguma_url_para_redirecionar')


@login_required
def adicionar_produto(request, venda_id):
    venda = get_object_or_404(Venda, id=venda_id)

    if venda.usuario != request.user:
        messages.error(request, "Você não tem permissão para modificar esta venda.")
        return redirect('iniciar_venda.html')

    if request.method == 'POST':
        if 'produto_id' in request.POST:
            produto_id = request.POST.get('produto_id')
            quantidade = int(request.POST.get('quantidade'))

            try:
                produto = Produto.objects.get(id=produto_id, usuario=request.user)
                
                # Verifica se há estoque suficiente para a venda
                if quantidade > produto.quantidade_estoque:
                    messages.error(request, f"Quantidade insuficiente em estoque para o produto {produto.nome}. Venda não pode ser concluída.")
                else:
                    # Adiciona o item à venda e atualiza o estoque
                    item_venda = ItemVenda.objects.create(
                        venda=venda,
                        produto=produto,
                        quantidade=quantidade,
                        preco_unitario=produto.preco
                    )
                    venda.total += produto.preco * quantidade
                    venda.save()
                    produto.diminuir_estoque(quantidade)
            except Produto.DoesNotExist:
                messages.error(request, "Produto não encontrado ou você não tem permissão para adicioná-lo.")

    produtos = Produto.objects.filter(usuario=request.user)
    lojas = Loja.objects.filter(usuario=request.user)

    return render(request, 'adicionar_produto.html', {
        'venda': venda,
        'produtos': produtos,
        'lojas': lojas,
    })


@login_required
def finalizar_venda(request, venda_id):
    venda = Venda.objects.get(id=venda_id)

    # Verifica se o usuário da venda é o mesmo que está logado
    if venda.usuario != request.user:
        messages.error(request, "Você não tem permissão para finalizar esta venda.")
        return redirect('alguma_url_para_redirecionar')

    # Obtém todos os itens da venda
    itens_venda = ItemVenda.objects.filter(venda=venda)

    try:
        # Inicia uma transação para garantir consistência nos dados
        with transaction.atomic():
            for item in itens_venda:
                # Obtém o produto associado ao item da venda
                produto = item.produto

                # Verifica se há estoque suficiente para a venda
                if item.quantidade <= produto.quantidade_estoque:
                    # Atualiza a quantidade em estoque do produto
                    produto.diminuir_estoque(item.quantidade)
                else:
                    # Se não houver estoque suficiente, cancela a venda
                    messages.error(request, f"Quantidade insuficiente em estoque para o produto {produto.nome}. Venda cancelada.")
                    return redirect('alguma_url_para_redirecionar')

            # Atualiza o status da venda
            venda.finalizada = True
            venda.save()

        messages.success(request, "Venda concluída com sucesso!")
        return redirect('listar_vendas')

    except Exception as e:
        messages.error(request, f"Ocorreu um erro ao finalizar a venda: {str(e)}")
        return redirect('alguma_url_para_redirecionar')


@login_required
def listar_vendas(request):
    vendas = Venda.objects.filter(usuario=request.user).annotate(total_produtos=Count('itens'))
    # Para cada venda, adiciona uma lista de produtos e suas quantidades
    for venda in vendas:
        itens_venda = ItemVenda.objects.filter(venda=venda)
        venda.produtos_quantidades = [(item.produto.nome, item.quantidade) for item in itens_venda]

    return render(request, 'gerenciarLoja/listas/venda.html', {'vendas': vendas})



@login_required
def get_total_venda(request, venda_id):
    venda = Venda.objects.get(id=venda_id)
    total = sum(item.produto.preco * item.quantidade for item in venda.itens.all())
    return JsonResponse({'total': total})


class VendaList(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    model = Venda
    template_name = "venda.html"
    context_object_name = 'vendas'  

    def get_queryset(self):
        queryset = super().get_queryset()
        queryset = queryset.filter(usuario=self.request.user)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Contar o número total de vendas
        context['total_vendas'] = Venda.objects.filter(usuario=self.request.user).count()
        return context
    
class LojaCreate(LoginRequiredMixin, CreateView):
    login_url = '/login/'
    model = Loja
    template_name = "gerenciarLoja/cadastrar_loja.html"
    form_class = LojaForm  
    success_url = reverse_lazy('listar-loja')  # Substitua 'listar-lojas' pelo nome da sua URL de lista de lojas

    def form_valid(self, form):
        form.instance.usuario = self.request.user  # Associa o usuário ao produto

        # Verifica se com o mesmo nome e usuário já existe
        loja_existente = Loja.objects.filter(usuario=self.request.user, nome=form.cleaned_data['nome']).exclude(id=form.instance.id).exists()

        if loja_existente:
            # Adiciona uma mensagem de erro ao formulário
            form.add_error('nome', 'Já existe uma loja cadastrada com esse nome para esse usuário.')
            return super().form_invalid(form)

        return super().form_valid(form)

class LojaUpdate(LoginRequiredMixin, UpdateView):
    login_url = '/login/'  # substitua por sua URL de login
    model = Loja
    template_name =  "gerenciarLoja/cadastrar_loja.html"
    form_class = LojaForm  # Substitua LojaForm pelo formulário correspondente
    success_url = reverse_lazy('listar-loja')  # Substitua 'listar-lojas' pelo nome da sua URL de lista de lojas

class LojaDelete(LoginRequiredMixin, DeleteView):
    login_url = '/login/'  # substitua por sua URL de login
    model = Loja
    template_name =  "gerenciarLoja/excluir_loja.html"
    success_url = reverse_lazy('listar-loja')  # Substitua 'listar-lojas' pelo nome da sua URL de lista de lojas

class LojaList(LoginRequiredMixin, ListView):
    login_url = '/login/'  # substitua por sua URL de login
    model = Loja
    template_name = "gerenciarLoja/listas/loja.html"
    context_object_name = 'lojas'  # Especifica o nome do objeto de contexto
    ordering = ['-id']  # opcional: ordene pela ID da loja ou outro campo

    def get_queryset(self):
        return Loja.objects.filter(usuario=self.request.user)



class ComentarioCreate(LoginRequiredMixin, CreateView):
    login_url = '/login/'  # Substitua pela sua URL de login
    model = Comentario
    template_name = "forum/comentario.html"  # Substitua pelo seu template
    form_class = ComentarioForm
    success_url = reverse_lazy('cadastrar-comentario')  # Substitua 'listar-comentario' pelo nome da sua URL de lista de comentários

    def form_valid(self, form):
        form.instance.autor = self.request.user
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['comentarios'] = Comentario.objects.order_by('-data_publicacao')  # Adiciona os comentários ao contexto
        return context
    
class ComentarioUpdate(LoginRequiredMixin, UpdateView):
    login_url = '/login/'  # Substitua pela sua URL de login
    model = Comentario
    template_name = "forum/editar_comentario.html"  # Substitua pelo seu template
    form_class = ComentarioForm
    success_url = reverse_lazy('listar-comentario')  # Substitua 'listar-comentario' pelo nome da sua URL de lista de comentários

class ComentarioDelete(LoginRequiredMixin, DeleteView):
    login_url = '/login/'  # Substitua pela sua URL de login
    model = Comentario
    template_name = "forum/excluir_comentario.html"  # Substitua pelo seu template
    success_url = reverse_lazy('listar-comentario')  # Substitua 'listar-comentario' pelo nome da sua URL de lista de comentários



def exibir_comentarios(request):
    comentarios = Comentario.objects.all()
    return render(request, 'exibir_comentarios.html', {'comentarios': comentarios})

