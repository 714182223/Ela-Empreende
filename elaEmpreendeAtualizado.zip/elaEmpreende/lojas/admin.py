from django.contrib import admin
from .models import Loja, Comentario, Venda


@admin.register(Loja)
class LojaAdmin(admin.ModelAdmin):
    list_display = ['nome', 'descricao']
    # Adicione outros campos do modelo que deseja exibir na lista do Django Admin


class ComentarioAdmin(admin.ModelAdmin):
    list_display = ('autor', 'texto', 'data_publicacao')  # Campos exibidos na lista de comentários


admin.site.register(Comentario)

admin.site.register(Venda)
